import React from "react"

export default function About(){
    return (
        <div className="about">
            <h3>About</h3>
            <p>I am a professional routesetter with a passion for technology. I am deeply interested in the freeing nature of automation and want to contribute to the growth of technology.</p>
        </div>
    )
}