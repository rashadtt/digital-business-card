import React from "react"

export default function Interests(){
    return (
        <div className="interests">
            <h3>Interests</h3>
            <p>Technology. Gaming. Climbing. Routesetting. Philosophy. Conversation. Connection.</p>
        </div>
    )
}